# Google Cloud Platform VPC network Module

## Overview
>The GCP VPC network module defines and creates new VPC (Virutal Private Cloud) network sent as Input.


  ## Pre-requisite

  >Terraform application
  >Google Cloud provider
  >Google-beta Cloud provider (This beta provider is for enabling logging feature in firewall policies of firewall module)



>**Figure 1.** *Virtual Private Cloud with network & subnets*

![architecture diagram](https://dev.azure.com/accenturecio08/81e18482-b5ea-4cc2-9c04-b73cd5f56a26/_apis/git/repositories/738d2d04-918a-4009-89cf-a8c9bf0dce9c/Items?path=%2FGCP_VPC_Arch1_diagram.png&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=master&download=false&resolveLfs=true&%24format=octetStream&api-version=5.0-preview.1)


## Usage 
> "gcp_create_subnet" & "gcp_create_global_firewall_rule" are wired to the create_vpc_network module since its mandatory to define the proper default subnets and firewall rules detailed in the Overview section for the approved network connectivities to each individual VPC and its subnets. This module will create VPC along with subnets per region or a list of regions and default global firewall rules base. Subnet module can create subnets across multiple regions. Users can input a single region name or a series of approved region names to create subnets in VPC. User need to input region name in this way: us-east1, us-central1,....

```ruby

resource "google_compute_network" "myvpc" {
  depends_on              = ["google_project_service.my_enabled_api"]
  description             = "Single and Global VPC only used for this project across all regions and zones"
  name                    = "${lower(var.enter_app_name)}-${lower(var.environment)}"
  auto_create_subnetworks = "false"
  project                 = "${var.enter_project_id}"
  routing_mode            = "REGIONAL"
}

module "gcp_create_subnet" {
  # Module source
  source = "acnciotfregistry.accenture.com/accenture-cio/netsubnet/google"

  # Module version
  version = "0.0.1"

  # Parameters
  enter_project_id           = "${var.enter_project_id}"
  enter_vpc_name             = "${google_compute_network.myvpc.name}"
  enter_specific_region_name = "${var.enter_specific_region_name}"
}


module "gcp_create_global_firewall_rule" {
  # Module source
  source = "acnciotfregistry.accenture.com/accenture-cio/createnetfw/google"

  # Module version
  version = "0.0.1"

  # Parameters
  enter_project_id = "${var.enter_project_id}"
  enter_vpc_name   = "${google_compute_network.myvpc.name}"
  enter_app_name   = "${var.enter_app_name}"
  environment      = "${var.environment}"
  private_subnets  = ["${module.gcp_create_subnet.privatesubpool}"]
  public_subnets   = ["${module.gcp_create_subnet.publicsubpool}"]
}


```

## Resources created 
>One VPC resource with each set of private and public subnets & one firewall resource will be created for each rule, detailed in Overview section. Here are one example.

- [`google_compute_network`](https://www.terraform.io/docs/providers/google/d/datasource_compute_network.html): create VPC network.

>>****Resource creation**: Virtual Private Cloud network

>>**Business case**: Create virtual network with required private & public subnets


>>**Required Parameters**:
>>- description: "Summary of the VPC usage."
>>- name: "Name of the VPC to be created received as Input"
>>- project: "Project ID where the VPC will be created received as Input."
>>- auto_create_subnetworks: "Disable the automatic creation of the Private/Public Subnets."
>>- routing_mode: "Routing mode for the VPC defined as REGIONAL as per standard."
>>- environment: "Enter the environment name (prd/npd) where the Resource is being deployed.Production - prd. Non-production - npd."
>>- enter_app_name: "Enter the name of the app entered as Input."
>>- enter_project_id: "Enter the ID of the project as input."

```ruby

resource "google_compute_network" "myvpc" {
  depends_on              = ["google_project_service.my_enabled_api"]
  description             = "Single and Global VPC only used for this project across all regions and zones"
  name                    = "${lower(var.enter_app_name)}-${lower(var.environment)}"
  auto_create_subnetworks = "false"
  project                 = "${var.enter_project_id}"
  routing_mode            = "REGIONAL"
}

```


## Module dependencies

>Required Modules:
  Project module

>Optional Modules:
**NONE**

## Input variables

    - environment: "Enter the environment name (prd/npd) where the Resource is being deployed.Production - prd. Non-production - npd."
    - enter_app_name: "Enter the name of the app entered as Input."
    - enter_project_id: "Enter the ID of the project as input."

>Optional Parameters:
**NONE**

## Output variables

>Name of the VPC. 
>vpcname - output of the name of created VPC. 


- [`google_compute_subnetwork`](https://www.terraform.io/docs/providers/google/d/datasource_compute_subnetwork.html): Create subnet in VPC network.

>**Resource creation**: Call module of subnet creation here

>>**Business case**: Create public & private subnets in VPC


>>**Required Parameters**:
>>- enter_vpc_name: "Name of the VPC to be used for Firewall rules definition."
>>- enter_specific_region_name: "List of regions where the subnets will be created in VPC."
>>- enter_project_id: "Enter the ID of the project as input."

```ruby

module "gcp_create_subnet" {
  # Module source
  source = "acnciotfregistry.accenture.com/accenture-cio/netsubnet/google"

  # Module version
  version = "0.0.1"

  # Parameters
  enter_project_id           = "${var.enter_project_id}"
  enter_vpc_name             = "${google_compute_network.myvpc.name}"
  enter_specific_region_name = "${var.enter_specific_region_name}"
}

```
## Module dependencies

>Required Modules:
  VPC module
    - firewall module

>Optional Modules:
**NONE**

## Input variables

    - enter_specific_region_name: "List of regions where the subnets will be created in VPC."
    - enter_project_id: "Enter the ID of the project as input."

>Optional Parameters:
**NONE**

## Output variables

>List of private & public created in VPC per region. 
>List_of_private_subnets - output of created private subnets. 
>List_of_public_subnets - output of created public subnets. 
>list_of_regions - ouput of list of regions. 
>public_subnet_pool - list of self links of created public subnet.
>private_subnet_pool - list of self links of created private subnet.

- [`google_compute_firewall`](https://www.terraform.io/docs/providers/google/r/compute_firewall.html): Egress Firewall rule.

>>**Resource creation**: Firewall rule ("google-beta" provider is required to enable the logging feature of firewall policies)

>>**Business case**: Public to Public Deny Unauthorized ports

>>**Required Parameters**:
>>- environment: "Enter the environment name (prd/npd) where the Resource is being deployed.Production - prd. Non-production - npd."
>>- enter_app_name: "Enter the name of the app entered as Input."
>>- enter_project_id: "Enter the ID of the project as input."
>>- enter_vpc_name: "Name of the VPC to be used for Firewall rules definition."
>>- private_subnets: "List of Private subnets CIDRs where the Firewall rules will apply."
>>- public_subnets: "List of Public subnets CIDRs where the Firewall rules will apply."

```ruby


module "gcp_create_global_firewall_rule" {
  # Module source
  source = "acnciotfregistry.accenture.com/accenture-cio/createnetfw/google"

  # Module version
  version = "0.0.1"

  # Parameters
  enter_project_id = "${var.enter_project_id}"
  enter_vpc_name   = "${google_compute_network.myvpc.name}"
  enter_app_name   = "${var.enter_app_name}"
  environment      = "${var.environment}"
  private_subnets  = ["${module.gcp_create_subnet.privatesubpool}"]
  public_subnets   = ["${module.gcp_create_subnet.publicsubpool}"]
}

``` 
 
## Module dependencies

>Required Modules:
    VPC module
        - subnet module

>Optional Modules:
**NONE**

## Input variables

    - environment: "Enter the environment name (prd/npd) where the Resource is being deployed.Production - prd. Non-production - npd."
    - enter_app_name: "Enter the name of the app entered as Input."
    - enter_project_id: "Enter the ID of the project as input."

    
>Optional Parameters:
**NONE**

## Output variables

>No outputs are required for this module.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Readme from Firewall
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# Google Cloud Platform VPC create subnet Module

## Overview
>The GCP VPC create subnet module defines and creates private and public subnets in VPC.

## Pre-requisite

>Terraform application
>Google Cloud provider


>**Figure 1.** *Virtual Private Cloud with network & subnets*

![architecture diagram](https://dev.azure.com/accenturecio08/81e18482-b5ea-4cc2-9c04-b73cd5f56a26/_apis/git/repositories/738d2d04-918a-4009-89cf-a8c9bf0dce9c/Items?path=%2FGCP_VPC_Arch1_diagram.png&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=master&download=false&resolveLfs=true&%24format=octetStream&api-version=5.0-preview.1)


## Usage 
> "create_create_subnet" is wired to the create_vpc_network module since its mandatory to define the proper default subnets detailed in the Overview section for the approved network connectivities to each individual VPC and its subnets. This module will create VPC along with subnets per region or a list of regions. User can input a single region name or a series of approved region names to create subnets in VPC. User need to add the region name in this way: us-east1, us-central1,.....

```ruby

# Private subnet creation module

resource "google_compute_subnetwork" "subnet_private" {
  depends_on               = ["google_project_service.my_enabled_api"]
  count                    = "${length(split(",", var.enter_specific_region_name))}"
  name                     = "${element(split(",", trimspace(lower(element(split(",", var.enter_specific_region_name), count.index)))), count.index)}-private-subnet"
  ip_cidr_range            = "${local.private_subnet_cidr[element(split(",", trimspace(lower(element(split(",", var.enter_specific_region_name), count.index)))), count.index)]}"
  network                  = "${var.enter_vpc_name}"
  project                  = "${var.enter_project_id}"
  region                   = "${element(split(",", trimspace(lower(element(split(",", var.enter_specific_region_name), count.index)))), count.index)}"
  enable_flow_logs         = "true"
  private_ip_google_access = "true"
}

# Pubic subnet creation module

resource "google_compute_subnetwork" "subnet_public" {
  depends_on               = ["google_project_service.my_enabled_api"]
  count                    = "${length(split(",", var.enter_specific_region_name))}"
  name                     = "${element(split(",", trimspace(lower(element(split(",", var.enter_specific_region_name), count.index)))), count.index)}-public-subnet"
  ip_cidr_range            = "${local.public_subnet_cidr[element(split(",", trimspace(lower(element(split(",", var.enter_specific_region_name), count.index)))), count.index)]}"
  network                  = "${var.enter_vpc_name}"
  project                  = "${var.enter_project_id}"
  region                   = "${element(split(",", trimspace(lower(element(split(",", var.enter_specific_region_name), count.index)))), count.index)}"
  enable_flow_logs         = "true"
  private_ip_google_access = "true"
}

```

## Resources created 
>Set of private and public subnets in VPC will be created, detailed in Overview section. Here are one example.

- [`google_compute_subnetwork`](https://www.terraform.io/docs/providers/google/d/datasource_compute_subnetwork.html): Create subnet in VPC network.

>>***Resource creation**: Call module of subnet creation here

>>**Business case**: Create public & private subnets in VPC


>>**Required Parameters**:

>>- name: "Name of the Subnet to be created. Naming convention: region-private/public-subnet"
>>- ip_cidr_range: "CIDR for the Subnet to be created, defined in the variable.tf file."
>>- network: "Name of the VPC where the Subnet will be created."
>>- project: "Project ID where the VPC Subnet will be created received as Input."
>>- region: "Defined region for the specific Subnet. It can be specific or approved all regions, based on application requirement."
>>- private_ip_google_access: "Enable PGA for improved intercommunication between subnets as per Standards."
>>- enable_flow_logs: "Enable Looging redirection as per Standards."
>>- enter_specific_region_name: "Enter the name of regions where you want to deploy subnets."
>>- enter_project_id: "Enter the ID of the Project as input."

```ruby

# Private subnet creation module

resource "google_compute_subnetwork" "subnet_private" {
  depends_on               = ["google_project_service.my_enabled_api"]
  count                    = "${length(split(",", var.enter_specific_region_name))}"
  name                     = "${element(split(",", trimspace(lower(element(split(",", var.enter_specific_region_name), count.index)))), count.index)}-private-subnet"
  ip_cidr_range            = "${local.private_subnet_cidr[element(split(",", trimspace(lower(element(split(",", var.enter_specific_region_name), count.index)))), count.index)]}"
  network                  = "${var.enter_vpc_name}"
  project                  = "${var.enter_project_id}"
  region                   = "${element(split(",", trimspace(lower(element(split(",", var.enter_specific_region_name), count.index)))), count.index)}"
  enable_flow_logs         = "true"
  private_ip_google_access = "true"
}

# Pubic subnet creation module

resource "google_compute_subnetwork" "subnet_public" {
  depends_on               = ["google_project_service.my_enabled_api"]
  count                    = "${length(split(",", var.enter_specific_region_name))}"
  name                     = "${element(split(",", trimspace(lower(element(split(",", var.enter_specific_region_name), count.index)))), count.index)}-public-subnet"
  ip_cidr_range            = "${local.public_subnet_cidr[element(split(",", trimspace(lower(element(split(",", var.enter_specific_region_name), count.index)))), count.index)]}"
  network                  = "${var.enter_vpc_name}"
  project                  = "${var.enter_project_id}"
  region                   = "${element(split(",", trimspace(lower(element(split(",", var.enter_specific_region_name), count.index)))), count.index)}"
  enable_flow_logs         = "true"
  private_ip_google_access = "true"
}

```
## Module dependencies

>Required Modules:
  NA

>Optional Modules:
**NONE**

## Input variables

    - enter_project_id: "Enter the Project ID where the VPC Subnet will be created received as Input."
		- enter_vpc_name: "Enter the name of VPC."
    - enter_specific_region_name: "Enter the name of regions where you want to deploy subnets. User need to add the region name in this way: us-east1, us-central1,....."


>Optional Parameters:
**NONE**

## Output variables

>List of private & public created in VPC per region. 
>regionlist - output list of regions where subnets are created. 
>publicsubpool - output list of public subnets. 
>privatesubpool - output list of private subnets. 
>private_subnet_output_details - formatted approach. 
>public_subnet_output_details - formatted approach. 
>privatesubnet - output self_links of deplpyed private subnets and are used for cloud nat router module. 
>publicsubnet - output self_links of deplpyed public subnets and are used for cloud nat router module.
