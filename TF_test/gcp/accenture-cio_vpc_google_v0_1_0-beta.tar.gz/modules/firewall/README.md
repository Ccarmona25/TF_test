# Google Cloud Platform Global Firewall Module

## Overview
>The GCP Global Firewall module defines and creates the corresponding default Firewall rulebase in existing Network VPC sent as Input.


>**Figure 1.** *Allowed network connectivities and default firewall rulebase*

![architecture diagram](https://dev.azure.com/accenturecio08/81e18482-b5ea-4cc2-9c04-b73cd5f56a26/_apis/git/repositories/738d2d04-918a-4009-89cf-a8c9bf0dce9c/Items?path=%2FGCP_Global_Firewall_diagram.png&versionDescriptor%5BversionOptions%5D=0&versionDescriptor%5BversionType%5D=0&versionDescriptor%5Bversion%5D=master&download=false&resolveLfs=true&%24format=octetStream&api-version=5.0-preview.1)


## Usage 
>set_global_firewall module is wired to the create_vpc_network module since its mandatory to define the proper default firewall rules detailed in the Overview section for the approved network connectivities to each individual VPC and its subnets. 

```ruby
module "gcp_create_global_firewall_rule" {
  # Module source
  source = "acnciotfregistry.accenture.com/accenture-cio/createnetfw/google"

  # Module version
  version = "0.1.0-alpha"

  # Parameters
  enter_project_id = "${var.enter_project_id}"
  enter_vpc_name   = "${google_compute_network.myvpc.name}"
  enter_app_name   = "${var.enter_app_name}"
  environment      = "${var.environment}"
  private_subnets  = ["${module.gcp_create_subnet.privatesubpool}"]
  public_subnets   = ["${module.gcp_create_subnet.publicsubpool}"]
}
```

## Resources created 
>One firewall resource will be created for each Rule detailed in the Overview section. Here are one example of Egress and Ingress rule since they difer in their definition.

- [`google_compute_firewall`](https://www.terraform.io/docs/providers/google/r/compute_firewall.html): Egress Firewall rule.

>>**Resource creation**: Firewall rule

>>**Business case**: ALLOW EGRESS CONNECTIVITY TO WEB SERVICES THROUGH HTTP AND HTTPS

>>**Required Parameters**:
>>- provider: GCP Google Beta provider is required for enabling logging.
>>- name: Name of the Firewall rule to be created.
>>- description: FASM-ID that references the rule to be setup.
>>- project: Project ID where the Firewall rule will be setup received as Input.
>>- network: Name of the VPC to be used for Firewall rule setup received as Input.
>>- destination_ranges: CIDR for network destination.
>>- direction: Declares the direction for evaluating the rule.[EGRESS/INGRESS]
>>- enable_logging: Enable Looging redirection as per Standards.
>>- priority: Integer that is applicable when evaluated with other rules. Lower integers indicate higher priorities. [0-65535]
>>- allow/deny: Defines if the rule is for Allowing the traffic or Denying it.
>>- protocol: Protocol evaluated in the rule.
>>- ports: List of ports involved in the rule.

```ruby
resource "google_compute_firewall""global-firewall-egress-allow-http-any-to-any"{
  depends_on         = ["google_project_service.my_enabled_api"]
  provider           = "google-beta" # Required for enabling logging (enable_logging = true)
  name               = "${var.environment}-${var.enter_vpc_name}-egress-allow-https-any-to-any"
  description        = "FASM-ID : 2429/2431 - VPC allow HTTPS egress traffic"
  project            = "${var.enter_project_id}"
  network            = "${var.enter_vpc_name}"
  destination_ranges = ["0.0.0.0/0"]
  direction          = "EGRESS"
  enable_logging     = true # Feature in Beta (google-beta provider is required)
  priority           = "30000"
  allow {
    protocol         = "tcp"
    ports            = ["80","443"]
  }
}
``` 

- [`google_compute_firewall`](https://www.terraform.io/docs/providers/google/r/compute_firewall.html): Ingress Firewall rule.

>>**Resource creation**: Firewall rule

>>**Business case**: ALLOW INGRESS CONNECTIVITY TO PUBLIC THROUGH HTTP AND HTTPS

>>**Required Parameters**:
>>- provider: GCP Google Beta provider is required for enabling logging.
>>- name: Name of the Firewall rule to be created.
>>- description: FASM-ID that references the rule to be setup.
>>- project: Project ID where the Firewall rule will be setup received as Input.
>>- network: Name of the VPC to be used for Firewall rule setup received as Input.
>>- source_ranges: CIDR for network source.
>>- target_tags: Declares the target tags to be evaluated [public/private]
>>- direction: Declares the direction for evaluating the rule.[EGRESS/INGRESS]
>>- enable_logging: Enable Looging redirection as per Standards.
>>- priority: Integer that is applicable when evaluated with other rules. Lower integers indicate higher priorities. [0-65535]
>>- allow/deny: Defines if the rule is for Allowing the traffic or Denying it.
>>- protocol: Protocol evaluated in the rule.
>>- ports: List of ports involved in the rule.

```ruby
resource "google_compute_firewall""global-firewall-ingress-allow-http-any-to-public"{
  depends_on     = ["google_project_service.my_enabled_api"]
  provider       = "google-beta" # Required for enabling logging (enable_logging = true)
  name           = "${var.environment}-${var.enter_vpc_name}-ingress-allow-http-any-to-pub"
  description    = "FASM-ID : 2548/2549 - VPC allow HTTP ingress traffic from Any to Public"
  project        = "${var.enter_project_id}"
  network        = "${var.enter_vpc_name}"
  source_ranges  = ["0.0.0.0/0"]
  target_tags    = ["public"]
  direction      = "INGRESS"
  enable_logging = true # Feature in Beta (google-beta provider is required)
  priority       = "30000"
  allow {
    protocol     = "tcp"
    ports        = ["80","443"]
  }
}
``` 
## Module dependencies

>Required Modules:
>>- **vpc**

>Optional Modules:
**NONE**

## Input variables

>Required Parameters:
>>- **enter_project_id**: Project ID where the Firewall rules will be defined.
>>- **enter_vpc_name**: Name of the VPC to be used for Firewall rules definition.
>>- **enter_app_name**: Name of the Application requesting the VPC module.
>>- **environment**: Environment where the Resource is being deployed.[sbx,prd,npd]
>>- **private_subnets**: List of Private subnets CIDRs where the Firewall rules will apply.
>>- **public_subnets**: List of Public subnets CIDRs where the Firewall rules will apply.

>Optional Parameters:
**NONE**

## Output variables

>>- **tf_module_name**: Module name to be used for versioning.
>>- **tf_module_version**: Module version to be used for versioning.

